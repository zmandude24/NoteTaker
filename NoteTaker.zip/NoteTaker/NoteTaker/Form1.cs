﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NoteTaker
{
    public partial class Form1 : Form
    {
        DataTable dataTable;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataTable = new DataTable();
            dataTable.Columns.Add("Title", typeof(string));
            dataTable.Columns.Add("Messages", typeof(string));

            dataGridView.DataSource = dataTable;

            dataGridView.Columns["Messages"].Visible = false;
            dataGridView.Columns["Title"].Width = 232;
        }

        private void buttonNew_Click(object sender, EventArgs e)
        {
            textTitle.Clear();
            textMessage.Clear();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            dataTable.Rows.Add(textTitle.Text, textMessage.Text);

            textTitle.Clear();
            textMessage.Clear();
        }

        private void buttonRead_Click(object sender, EventArgs e)
        {
            if (dataGridView.CurrentCell == null) return;

            int index = dataGridView.CurrentCell.RowIndex;
            textTitle.Text = dataTable.Rows[index].ItemArray[0].ToString();
            textMessage.Text = dataTable.Rows[index].ItemArray[1].ToString();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView.CurrentCell == null) return;

            int index = dataGridView.CurrentCell.RowIndex;
            dataTable.Rows[index].Delete();
        }
    }
}
